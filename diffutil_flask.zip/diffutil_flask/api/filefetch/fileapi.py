from flask_restful import Resource
from flask import jsonify
import os,time,datetime
class File(Resource):

    def get(self):
        f_list = []
        try:
            for filename in os.listdir(os.getcwd()):

                if os.path.isfile(filename):
                    type="File"
                elif os.path.isdir(filename):
                    type = "Folder"
                else:
                    type = "Unknown"
                t=os.path.getmtime(filename)
                t = os.path.getmtime(filename)
                f_list.append({"fileName":filename,"type":type,"size":os.path.getsize(filename), \
                               "modifiedDate":time.ctime(t)})

            return jsonify({'status': 'success', 'data': f_list}, 200)

        except:
            return {'status': 'failed', 'data':'something went wrong'}, 400